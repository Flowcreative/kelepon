  <main>
      <header class="page-header page-header-dark bg-teal pb-10">
          <div class="container-xl px-4">
              <div class="page-header-content pt-4">
                  <div class="row align-items-center justify-content-between">
                      <div class="col-auto mt-4">
                          <h1 class="page-header-title">
                              <div class="page-header-icon"><i data-feather="file"></i></div>
                              Mata lomba baru bisa dipilih di esok hari :)
                          </h1>
                          Untuk saat ini silahkan lengkapi data diri anda
                      </div>
                  </div>
              </div>
          </div>
      </header>
      <!-- Main page content-->