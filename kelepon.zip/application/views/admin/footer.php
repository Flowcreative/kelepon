   <footer class="footer-admin mt-auto footer-light">
       <div class="container-xl px-4">
           <div class="row">
               <div class="col-md-6 small">Copyright &copy; PRAMUKA UNIB 2021</div>
               <div class="col-md-6 text-md-end small">
                   <a href="#!">Privacy Policy</a>
                   &middot;
                   <a href="#!">Terms &amp; Conditions</a>
               </div>
           </div>
       </div>
   </footer>
   </div>
   </div>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.js" crossorigin="anonymous"></script>
   <script src="<?= base_url('src/dashboard/') ?>assets/demo/chart-area-demo.js"></script>
   <script src="<?= base_url('src/dashboard/') ?>assets/demo/chart-bar-demo.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/litepicker/dist/bundle.js" crossorigin="anonymous"></script>
   <script src="<?= base_url('src/dashboard/') ?>js/litepicker.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
   <script src="<?= base_url('src/dashboard/') ?>js/scripts.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
   <script src="<?= base_url('src/dashboard/') ?>js/datatables/datatables-simple-demo.js"></script>
   </body>

   </html>