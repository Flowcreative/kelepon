<!-- Timeline Item 1-->
<div class="timeline-item">
    <div class="timeline-item-marker">
        <div class="timeline-item-marker-text">4 Nov</div>
        <div class="timeline-item-marker-indicator bg-green"></div>
    </div>
    <div class="timeline-item-content">
        Pembukaan pendaftaran
        <a class="fw-bold text-dark" href="#!">Online</a>
        via Website klepon.online
    </div>
</div>
<!-- Timeline Item 2-->
<div class="timeline-item">
    <div class="timeline-item-marker">
        <div class="timeline-item-marker-text">4 Nov</div>
        <div class="timeline-item-marker-indicator bg-blue"></div>
    </div>
    <div class="timeline-item-content">
        Pengiriman karya
        <a class="fw-bold text-dark" href="#!">Via</a>
        Website klepon.online
    </div>
</div>
<!-- Timeline Item 3-->
<div class="timeline-item">
    <div class="timeline-item-marker">
        <div class="timeline-item-marker-text">17 Nov</div>
        <div class="timeline-item-marker-indicator bg-purple"></div>
    </div>
    <div class="timeline-item-content">
        Penutupan
        <a class="fw-bold text-dark" href="#!">Pendaftaran</a>
        Non aktif pendaftaran user
    </div>
</div>
<!-- Timeline Item 4-->
<div class="timeline-item">
    <div class="timeline-item-marker">
        <div class="timeline-item-marker-text">18 Nov</div>
        <div class="timeline-item-marker-indicator bg-yellow"></div>
    </div>
    <div class="timeline-item-content">Batas akhir pengumpulan karya</div>
</div>
<!-- Timeline Item 5-->
<div class="timeline-item">
    <div class="timeline-item-marker">
        <div class="timeline-item-marker-text">19-20 Nov</div>
        <div class="timeline-item-marker-indicator bg-green"></div>
    </div>
    <div class="timeline-item-content">
        Penjurian / proses
        <a class="fw-bold text-dark" href="#!">Penilaian</a>
        karya
    </div>
</div>
<!-- Timeline Item 6-->
<div class="timeline-item">
    <div class="timeline-item-marker">
        <div class="timeline-item-marker-text">21 Nov</div>
        <div class="timeline-item-marker-indicator bg-purple"></div>
    </div>
    <div class="timeline-item-content">
        <a class="fw-bold text-dark" href="#!">Acara puncak</a>
    </div>
</div>