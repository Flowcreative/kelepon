<?php

function timeline()
{
    $klepon = get_instance();
    $klepon->load->view('all/timeline');
}
