  <!--================Footer Area =================-->
  <footer class="footer_area p_120">
      <div class="container">
          <div class="row footer_inner">
              <div class="col-lg-4 col-sm-4">
                  <aside class="f_widget ab_widget">
                      <div class="f_title">
                          <h3>Sponsorship</h3>
                      </div>
                      <p>
                      <div class="col-lg-4 col-sm-4">
                          Disini logo sponsor
                      </div>
                      </p>
                  </aside>
              </div>
              <div class="col-lg-4 col-sm-4 justify-content-center">
                  <aside class="f_widget news_widget">
                      <div class="f_title">
                          <h3>Tentang Kami</h3>
                      </div>
                      <div id="mc_embed_signup align-center ">
                          <img src="<?= base_url('src/landing/img/') ?>kami.png" alt="">
                      </div>
                  </aside>
              </div>
              <div class="col-lg-4 col-sm-4">
                  <aside class="f_widget social_widget">
                      <div class="f_title">
                          <h3>Media Partner</h3>
                      </div>
                      <ul class="list">
                          <li>
                              <a href="#">
                                  <img src="<?= base_url('src/landing/img/mediapartner/') ?>gebay.png" alt="" height="50px" width="95px">
                              </a>
                          </li>
                          <li>
                              <a href="#">
                                  <img src="<?= base_url('src/landing/img/mediapartner/') ?>ilook.png" alt="" height="80px" width="90px">
                              </a>
                          </li>
                          <li>
                              <a href="#">
                                  <img src="<?= base_url('src/landing/img/mediapartner/') ?>update.png" alt="" height="65px" width="120px">
                              </a>
                          </li>
                      </ul>
                  </aside>
              </div>
          </div>
          <p>
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
              Copyright &copy;<script>
                  document.write(new Date().getFullYear());
              </script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>.Downloaded from <a href="https://themeslab.org/" target="_blank">Themeslab</a>
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
          </p>
      </div>
  </footer>
  <!--================End Footer Area =================-->





  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="<?= base_url('src/landing/') ?>js/jquery-3.2.1.min.js"></script>
  <script src="<?= base_url('src/landing/') ?>js/popper.js"></script>
  <script src="<?= base_url('src/landing/') ?>js/bootstrap.min.js"></script>
  <script src="<?= base_url('src/landing/') ?>js/stellar.js"></script>
  <script src="<?= base_url('src/landing/') ?>vendors/lightbox/simpleLightbox.min.js"></script>
  <script src="<?= base_url('src/landing/') ?>vendors/nice-select/js/jquery.nice-select.min.js"></script>
  <script src="<?= base_url('src/landing/') ?>vendors/isotope/imagesloaded.pkgd.min.js"></script>
  <script src="<?= base_url('src/landing/') ?>vendors/isotope/isotope-min.js"></script>
  <script src="<?= base_url('src/landing/') ?>vendors/owl-carousel/owl.carousel.min.js"></script>
  <script src="<?= base_url('src/landing/') ?>js/jquery.ajaxchimp.min.js"></script>
  <script src="<?= base_url('src/landing/') ?>vendors/counter-up/jquery.waypoints.min.js"></script>
  <script src="<?= base_url('src/landing/') ?>vendors/counter-up/jquery.counterup.min.js"></script>
  <script src="<?= base_url('src/landing/') ?>js/mail-script.js"></script>
  <!--gmaps Js-->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
  <script src="<?= base_url('src/landing/') ?>js/gmaps.min.js"></script>
  <script src="<?= base_url('src/landing/') ?>js/theme.js"></script>
  </body>

  </html>